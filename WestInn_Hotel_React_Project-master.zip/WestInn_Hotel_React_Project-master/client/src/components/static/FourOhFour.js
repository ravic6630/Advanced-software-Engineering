import React, { Component } from 'react';

class FourOhFour extends Component {
      render() {
          return (
                <div>
                    <h1>404 page. Route not found</h1>
                </div>
          );
      }
}

export default FourOhFour;